#!/bin/bash -e -o pipefail

shutdown -r now